import "dotenv/config";
import express from "express";
import cors from "cors";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
const PORT = process.env.PORT || 8787;
const API = "https://1click.chaindefuser.com";
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.use(cors({ origin: process.env.APP_ORIGIN?.split(",") || true }));
app.use(express.json({ limit: "1mb" }));

async function oneClick(pathname, options = {}) {
  const headers = {
    "content-type": "application/json",
    ...(options.headers || {})
  };
  if (process.env.NEAR_INTENTS_JWT) {
    headers.authorization = `Bearer ${process.env.NEAR_INTENTS_JWT}`;
  }
  const response = await fetch(`${API}${pathname}`, { ...options, headers });
  const raw = await response.text();
  let data;
  try { data = raw ? JSON.parse(raw) : {}; }
  catch { data = { message: raw }; }
  if (!response.ok) {
    const error = new Error(data.message || data.error || `NEAR Intents returned HTTP ${response.status}`);
    error.status = response.status;
    throw error;
  }
  return data;
}

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "IntentPay API" }));

app.get("/api/config", (_req, res) => {
  res.json({
    merchantName: process.env.MERCHANT_NAME || "IntentPay Merchant",
    evmPayoutConfigured: Boolean(process.env.MERCHANT_EVM_PAYOUT_ADDRESS),
    nearPayoutConfigured: Boolean(process.env.MERCHANT_NEAR_PAYOUT_ADDRESS),
    intentsJwtConfigured: Boolean(process.env.NEAR_INTENTS_JWT)
  });
});

app.get("/api/tokens", async (_req, res) => {
  try {
    res.json(await oneClick("/v0/tokens"));
  } catch (error) {
    res.status(error.status || 502).json({ error: error.message });
  }
});

app.post("/api/quote", async (req, res) => {
  try {
    const { originAsset, destinationAsset, amount, refundTo, recipient } = req.body || {};
    if (![originAsset, destinationAsset, amount, refundTo, recipient].every(v => typeof v === "string" && v.trim())) {
      return res.status(400).json({ error: "originAsset, destinationAsset, amount, refundTo and recipient are required." });
    }
    if (!/^\d+$/.test(amount)) {
      return res.status(400).json({ error: "Amount must be an integer in the token's smallest unit." });
    }

    const registryResponse = await oneClick("/v0/tokens");
    const registry = Array.isArray(registryResponse) ? registryResponse : (registryResponse.tokens || []);
    const hasAsset = id => registry.some(token => (token.assetId || token.asset_id) === id);
    if (!hasAsset(originAsset) || !hasAsset(destinationAsset)) {
      return res.status(400).json({ error: "A selected asset is not present in the current NEAR Intents token registry." });
    }

    // This payload follows the 1Click quote request shape; verify against the
    // current official API docs before using real funds in production.
    const payload = {
      dry: false,
      swapType: "EXACT_INPUT",
      originAsset,
      destinationAsset,
      amount,
      recipient,
      refundTo,
      depositType: "ORIGIN_CHAIN",
      recipientType: "DESTINATION_CHAIN",
      refundType: "ORIGIN_CHAIN",
      slippageTolerance: Number(process.env.SLIPPAGE_BPS || 100),
      referral: "intentpay"
    };
    res.json(await oneClick("/v0/quote", { method: "POST", body: JSON.stringify(payload) }));
  } catch (error) {
    res.status(error.status || 502).json({ error: error.message });
  }
});

app.post("/api/deposit/submit", async (req, res) => {
  try {
    const { txHash, depositAddress } = req.body || {};
    if (!txHash || !depositAddress) {
      return res.status(400).json({ error: "txHash and depositAddress are required." });
    }
    res.json(await oneClick("/v0/deposit/submit", {
      method: "POST",
      body: JSON.stringify({ txHash, depositAddress })
    }));
  } catch (error) {
    res.status(error.status || 502).json({ error: error.message });
  }
});

app.get("/api/status", async (req, res) => {
  try {
    const { depositAddress, depositMemo } = req.query;
    if (!depositAddress) return res.status(400).json({ error: "depositAddress is required." });
    const params = new URLSearchParams({ depositAddress: String(depositAddress) });
    if (depositMemo) params.set("depositMemo", String(depositMemo));
    res.json(await oneClick(`/v0/status?${params.toString()}`));
  } catch (error) {
    res.status(error.status || 502).json({ error: error.message });
  }
});

if (process.env.NODE_ENV === "production") {
  app.use(express.static(path.join(__dirname, "dist")));
  app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "dist", "index.html")));
}

app.listen(PORT, () => console.log(`IntentPay API listening on :${PORT}`));
