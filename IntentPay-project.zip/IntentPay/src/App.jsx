import { useEffect, useMemo, useState } from "react";
import { BrowserProvider, Contract, parseUnits } from "ethers";

const CHAINS = {
  eth: { name: "Ethereum", id: 1, hex: "0x1" },
  base: { name: "Base", id: 8453, hex: "0x2105" },
  arb: { name: "Arbitrum One", id: 42161, hex: "0xa4b1" },
  op: { name: "Optimism", id: 10, hex: "0xa" },
  polygon: { name: "Polygon", id: 137, hex: "0x89" },
  bsc: { name: "BNB Smart Chain", id: 56, hex: "0x38" },
  avax: { name: "Avalanche", id: 43114, hex: "0xa86a" },
  scroll: { name: "Scroll", id: 534352, hex: "0x82750" },
  gnosis: { name: "Gnosis", id: 100, hex: "0x64" },
  aurora: { name: "Aurora", id: 1313161554, hex: "0x4e454152" },
  berachain: { name: "Berachain", id: 80094, hex: "0x138de" },
  monad: { name: "Monad", id: 143, hex: "0x8f" },
  plasma: { name: "Plasma", id: 9745, hex: "0x2611" },
  xlayer: { name: "X Layer", id: 196, hex: "0xc4" }
};
const ERC20_ABI = ["function transfer(address to, uint256 amount) returns (bool)"];

function networkOf(token) {
  const id = String(token.blockchain || token.network || "").toLowerCase();
  return CHAINS[id] || { name: id || "Other network", id: null };
}
function isEvm(token) {
  return Boolean(networkOf(token).id && token.contractAddress && /^0x/.test(token.contractAddress));
}
function label(token) {
  return `${token.symbol || token.assetId} · ${networkOf(token).name}`;
}

export default function App() {
  const [tokens, setTokens] = useState([]);
  const [originId, setOriginId] = useState("");
  const [destinationId, setDestinationId] = useState("");
  const [amount, setAmount] = useState("1");
  const [wallet, setWallet] = useState("");
  const [quote, setQuote] = useState(null);
  const [status, setStatus] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch("/api/tokens")
      .then(r => { if (!r.ok) throw new Error("Unable to load the live NEAR Intents token list."); return r.json(); })
      .then(data => {
        const rows = Array.isArray(data) ? data : data.tokens || [];
        setTokens(rows);
        const evm = rows.find(t => isEvm(t));
        const stable = rows.find(t => ["USDC", "USDT"].includes(String(t.symbol || "").toUpperCase()));
        setOriginId(evm?.assetId || evm?.asset_id || "");
        setDestinationId(stable?.assetId || stable?.asset_id || "");
      })
      .catch(e => setError(e.message));
  }, []);

  const origin = useMemo(() => tokens.find(t => (t.assetId || t.asset_id) === originId), [tokens, originId]);
  const destination = useMemo(() => tokens.find(t => (t.assetId || t.asset_id) === destinationId), [tokens, destinationId]);
  const evmTokens = tokens.filter(isEvm);
  const stableTokens = tokens.filter(t => ["USDC", "USDT"].includes(String(t.symbol || "").toUpperCase()));

  async function connectWallet() {
    try {
      if (!window.ethereum) throw new Error("Install MetaMask or another injected EVM wallet.");
      const provider = new BrowserProvider(window.ethereum);
      await provider.send("eth_requestAccounts", []);
      setWallet(await (await provider.getSigner()).getAddress());
      setError("");
    } catch (e) { setError(e.message); }
  }

  async function createQuote() {
    setBusy(true); setError(""); setQuote(null); setStatus("");
    try {
      if (!wallet) throw new Error("Connect your EVM wallet first.");
      if (!origin || !destination) throw new Error("Choose a supported payment asset and payout asset.");
      if (!isEvm(origin)) throw new Error("This version supports EVM source-wallet deposits only. NEAR wallet deposits are not enabled yet.");
      const amountAtomic = parseUnits(amount, Number(origin.decimals ?? 18)).toString();
      const response = await fetch("/api/quote", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          originAsset: origin.assetId || origin.asset_id,
          destinationAsset: destination.assetId || destination.asset_id,
          amount: amountAtomic,
          refundTo: wallet,
          recipient: wallet
        })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Quote request failed.");
      const q = data.quote || data;
      if (!q.depositAddress) throw new Error("The quote response did not include a deposit address.");
      setQuote(data);
      setStatus("Quote created. Check the details before sending funds.");
    } catch (e) { setError(e.message); }
    finally { setBusy(false); }
  }

  async function sendPayment() {
    setBusy(true); setError("");
    try {
      if (!quote || !origin || !isEvm(origin)) throw new Error("No valid EVM payment quote.");
      const q = quote.quote || quote;
      const depositAddress = q.depositAddress;
      const amountIn = q.amountIn;
      if (!amountIn || !/^\\d+$/.test(String(amountIn))) throw new Error("The quote has no valid exact input amount. No transaction was sent.");
      const provider = new BrowserProvider(window.ethereum);
      const chain = networkOf(origin);
      const current = await provider.getNetwork();
      if (Number(current.chainId) !== chain.id) {
        await window.ethereum.request({ method: "wallet_switchEthereumChain", params: [{ chainId: chain.hex }] });
      }
      const signer = await provider.getSigner();
      const contract = new Contract(origin.contractAddress, ERC20_ABI, signer);
      const tx = await contract.transfer(depositAddress, amountIn);
      setStatus("Transaction sent. Waiting for on-chain confirmation…");
      await tx.wait();
      const submit = await fetch("/api/deposit/submit", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ txHash: tx.hash, depositAddress })
      });
      const submitData = await submit.json();
      if (!submit.ok) throw new Error(submitData.error || "Could not notify the routing service of the deposit.");
      setStatus("Deposit transaction confirmed. Check settlement status for the final result.");
    } catch (e) { setError(e.shortMessage || e.message); }
    finally { setBusy(false); }
  }

  async function checkStatus() {
    if (!quote) return;
    const q = quote.quote || quote;
    try {
      const response = await fetch(`/api/status?depositAddress=${encodeURIComponent(q.depositAddress)}`);
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Could not fetch payment status.");
      setStatus(`Payment status: ${data.status || data.quoteStatus || "Status response received"}`);
    } catch (e) { setError(e.message); }
  }

  const q = quote?.quote || quote;
  return <main className="page">
    <nav className="nav"><div className="brand"><span className="brand-mark">I</span> IntentPay</div><span className="network-pill">NEAR INTENTS</span></nav>
    <section className="hero">
      <div className="eyebrow">ONE CHECKOUT. MANY CHAINS.</div>
      <h1>Pay from anywhere.<br/><span>Settle where you want.</span></h1>
      <p className="sub">A cross-chain checkout concept powered by NEAR Intents. Choose a supported asset, request a live quote and route payment across networks.</p>
    </section>
    <section className="checkout">
      <div className="checkout-head"><div><small>SECURE CHECKOUT DEMO</small><h2>Complete your payment</h2></div><span className="live-dot">Live assets</span></div>
      <label>Pay with</label>
      <select value={originId} onChange={e => setOriginId(e.target.value)}>
        {evmTokens.map(t => <option key={t.assetId || t.asset_id} value={t.assetId || t.asset_id}>{label(t)}</option>)}
      </select>
      <label>Amount</label>
      <input value={amount} onChange={e => setAmount(e.target.value)} inputMode="decimal" placeholder="0.00"/>
      <label>Destination asset</label>
      <select value={destinationId} onChange={e => setDestinationId(e.target.value)}>
        {stableTokens.map(t => <option key={t.assetId || t.asset_id} value={t.assetId || t.asset_id}>{label(t)}</option>)}
      </select>
      <div className="wallet-row">
        {wallet ? <span className="wallet-address">{wallet.slice(0, 7)}…{wallet.slice(-5)}</span> : <span className="muted">Connect an EVM wallet to continue</span>}
        <button className="secondary" onClick={connectWallet}>{wallet ? "Connected" : "Connect wallet"}</button>
      </div>
      <button className="primary" disabled={busy || !origin || !destination} onClick={createQuote}>{busy ? "Please wait…" : "Get payment quote"}</button>
      {q?.depositAddress && <div className="quote-box">
        <div className="quote-title">Unique deposit address</div>
        <code>{q.depositAddress}</code>
        <p>Review the quote amount and expiry returned by NEAR Intents before paying.</p>
        <button className="primary" onClick={sendPayment} disabled={busy}>Send payment from wallet</button>
        <button className="secondary full" onClick={checkStatus}>Check settlement status</button>
      </div>}
      {status && <p className="status">{status}</p>}
      {error && <p className="error">{error}</p>}
      <p className="fine">Mainnet transactions use real funds and network fees. This is an early integration scaffold, not an audited payment product. Use tiny test amounts only. Never share your seed phrase or private key.</p>
    </section>
    <footer>Built with NEAR Intents · Live token registry · {tokens.length} assets loaded</footer>
  </main>;
}