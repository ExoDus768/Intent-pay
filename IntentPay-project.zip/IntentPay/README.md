# IntentPay

**Universal cross-chain checkout powered by NEAR Intents.**

IntentPay is an early merchant-checkout scaffold. It discovers assets from the NEAR Intents token registry, requests a 1Click quote, displays the returned deposit address, and provides an EVM wallet deposit/status flow.

## Included

- React + Vite frontend.
- Express API proxy for NEAR Intents 1Click.
- Live token discovery (`GET /v0/tokens`); no hardcoded token asset IDs.
- Quote creation, deposit notification, and status lookup API routes.
- EVM wallet connection and ERC-20 transfer UI.
- Starter Vercel configuration and environment template.

## Important limitations

- This is **not yet a production-ready payment processor** and has not been audited.
- EVM source-wallet payments are the only wallet deposit flow scaffolded here. NEAR wallet signing and NEP-141 deposits are not implemented.
- The current UI uses the connected wallet as the quote recipient. A real merchant checkout must securely use the merchant's configured public payout address and validate it on the server before accepting customer funds.
- Token registry field names and 1Click request/response shapes can change. Verify them against the current official API documentation before mainnet use.
- Mainnet payments use real funds and gas. Do not test with money you cannot afford to lose.
- Never enter or store a seed phrase or private key in this project.

## Run locally

Install Node.js 20 or later, then:

```bash
npm install
cp .env.example .env
npm run dev
```

Open the Vite URL printed in your terminal, usually `http://localhost:5173`.

Add your NEAR Intents JWT to the server-side `.env` file if your API access requires it. Never prefix it with `VITE_` or expose it to the browser.

## Environment variables

See `.env.example`. Do not commit your real `.env` file.

## API routes

- `GET /api/health`
- `GET /api/config`
- `GET /api/tokens`
- `POST /api/quote`
- `POST /api/deposit/submit`
- `GET /api/status?depositAddress=...`

## Deployment

The included `vercel.json` is a starting point, not a verified deployment. Configure the environment variables in your hosting dashboard and test the serverless routing before using mainnet funds.

## NEAR Intents docs

https://docs.near-intents.org/near-intents/integration/distribution-channels/1click-api
